#!/usr/bin/env python3
"""Reject a changed Workflow source at the real CLI evaluator boundary."""

import argparse
import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--codewhale", type=Path, required=True)
    parser.add_argument("--workflow-source", type=Path, required=True)
    parser.add_argument("--fixture-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    fixture = args.fixture_dir.resolve()
    script = args.workflow_source.read_text() + "\n"
    payload = {
        "action": "run",
        "script": script,
        "args": {
            "strategy": "search",
            "brief": "Verify the isolated JSON probe",
            "n": 2,
            "model": "deepseek-flash",
            "writeRoots": ["src"],
            "evaluator": {"manifestPath": str(fixture / "evaluator.json")},
        },
    }
    before = set(Path(tempfile.gettempdir()).glob("codewhale-evaluator-workflow_*"))
    env = os.environ.copy()
    env.update({
        "DEEPSEEK_API_KEY": "synthetic-local-only",
        "CODEWHALE_HOME": str(fixture / "host-home"),
        "CODEWHALE_TELEMETRY": "0",
        "CODEWHALE_NO_UPDATE_CHECK": "1",
        "HTTPS_PROXY": "http://127.0.0.1:9",
        "HTTP_PROXY": "http://127.0.0.1:9",
        "NO_PROXY": "127.0.0.1,localhost",
    })
    command = [
        str(args.codewhale.resolve()), "--config", str(fixture / "config.toml"),
        "--workspace", str(fixture / "workspace"), "--provider", "deepseek",
        "--model", "deepseek-flash", "--sandbox-mode", "workspace-write",
        "workflow-tool", "--approval-source", "explicit-workflow-command",
        "--input-json", json.dumps(payload, separators=(",", ":")),
    ]
    completed = subprocess.run(
        command, cwd=fixture / "workspace", env=env,
        capture_output=True, text=True, timeout=30, check=False,
    )
    (output / "stdout.log").write_text(completed.stdout)
    (output / "stderr.log").write_text(completed.stderr)
    after = set(Path(tempfile.gettempdir()).glob("codewhale-evaluator-workflow_*"))
    message = "verified evaluator requires the checked-in search Workflow"
    receipt = {
        "binary_sha256": hashlib.sha256(args.codewhale.read_bytes()).hexdigest(),
        "authorized_source_sha256": hashlib.sha256(
            args.workflow_source.read_bytes()).hexdigest(),
        "mutated_source_sha256": hashlib.sha256(script.encode()).hexdigest(),
        "exit_code": completed.returncode,
        "expected_rejection_found": message in completed.stdout + completed.stderr,
        "new_evaluator_roots": [str(path) for path in sorted(after - before)],
    }
    receipt["pass"] = (
        receipt["authorized_source_sha256"] != receipt["mutated_source_sha256"]
        and receipt["expected_rejection_found"]
        and not receipt["new_evaluator_roots"]
    )
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return 0 if receipt["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
