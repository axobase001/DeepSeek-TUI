# Codewhale #7250 evaluator evidence

PR: https://github.com/codewhale-hq/Codewhale/pull/7294  
Issue reply: https://github.com/codewhale-hq/Codewhale/issues/7250#issuecomment-6794896109  
Source commit: `e365276d6a56849fad09e3d30691b219a52bd3ec`  
Base commit: `3020f4306be1d6a56dbc97cb7b6969e28cdaefa5`

The final full CLI build, six focused Rust tests, rustfmt, cargo check, and
strict clippy ran in [GitHub Actions run 43028514457](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43028514457).
The Linux binary artifact ZIP has SHA256
`e35e59cede3b4fa9e2f4e8b5ad8df178fbd5b00146f47632ae70ec3e44ebbdd7`.
Its CLI SHA256 is `bc9a5a53b76ae88d51eef21e041f17e1230f12792ee0fa87fab8eec1880f82fd`;
its focused Rust test binary SHA256 is
`23c90136be0fe9d2b76c26caf96c20cd3ab33ed4959ab8d61ab133be274a987c`.

`positive-e365.tar.gz` contains the same binaries' build receipt, native
Linux test log (6 passed, bubblewrap available), the real Workflow CLI run,
public and held-out cases, sealed artifacts, per-case logs, and the legacy
no-evaluator control. Its SHA256 is
`e7dd222bc8a85cbdf72ffecd91b2ec7e8b9623eef6b6990a2af26a4be994f62f`.
All inputs and provider responses are synthetic or local; no paid API was used.

Verify the sealed result without trusting the E2E runner's `pass` field:

```sh
python3 verify-native-evidence.py positive-e365.tar.gz
```

Expected result: seven saved case outputs independently match the host oracle;
the fake self-reported PASS fails, the isolated candidate and held-out replay
pass, the Workflow returns `proposal_only`, and the legacy path completes
without evaluator receipts.

`validation-ledger.md` records all commands and the earlier negative runs.
`negative-evidence.tar.gz`, `timed-evaluation-first.json`, and
`timed-evaluation-first.stderr.log` preserve the original failed fixture and
CLI attempts. `positive-4ba39ea.tar.gz` preserves the first full native PASS.
`tool-search-probe.py` is an additional writer-tool boundary probe; its
observations are identified separately from the OS sandbox test.
