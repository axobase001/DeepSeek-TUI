# CodeWhale PR #7294 maintainer-review evidence

Source PR: https://github.com/codewhale-hq/Codewhale/pull/7294  
Final source commit: `750eedb774f6c1d43d6689afb7abbd18844968da`  
Issue: https://github.com/codewhale-hq/Codewhale/issues/7250

## Reproduce the receipt audit

Unzip this bundle, then run:

```sh
python verify-native-evidence-7294.py final-750eedb-native-evidence.tar.gz
```

It recomputes seven case decisions from captured stdout and the trusted oracle,
checks the sealed artifact/tree and binary identities, and checks the final
review-only proposal plus the no-evaluator control. The native tar also carries
the non-root bubblewrap logs, the original Python 3.6 launcher failure, the
successful Python 3.11 rerun, and the Workflow-source rejection control.

`SHA256SUMS.txt` binds every bundled file. The final binary ZIP contains the
exact Rocky Linux 8 CLI and Rust test executable used on the 47 VPS. Its
internal build receipt records source commit, Rust and glibc versions, and
both executable hashes. The CLI SHA-256 is
`c2da06b2a23a55443cabbfc90b425656232349e98b97f906c5034a1b2b62f550`.

## Packaging result

- `final-standard-package-evidence.zip`: `cargo package --list --locked`
  succeeded. `cargo package --locked` exited 101 because crates.io did not
  provide `codewhale-agent 0.10.3` at validation time. This log is retained.
- `final-package-isolation-evidence.zip`: the listed engine file set compiled
  with local sibling 0.10.3 crates after the repository Workflow source was
  removed from a fresh temporary checkout. This is a separate source package
  compatibility check, with exit 0.

The full command, platform, count, exit and CI links are in
`PR7294_review_fixes_validation_2026-11-13.md`. Historical failed and passing
evidence from the first evaluator PR remains in this bundle. All native model
responses came from a local scripted HTTP provider and synthetic credentials.
