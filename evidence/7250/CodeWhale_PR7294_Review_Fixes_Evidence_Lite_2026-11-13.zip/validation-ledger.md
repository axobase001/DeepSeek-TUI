# Codewhale #7250 evaluator validation ledger

All times are UTC on 2026-11-11. The provider used by native Workflow probes
is a local scripted HTTP fixture with a synthetic key. No paid model API was
called.

## First compiled slice

- Source: `8107607edcb97bb83b3846f491efc344a80ee757`.
- [Hosted build and Rust tests](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43012852219): `cargo build --locked -p codewhale-cli` succeeded; `cargo test --locked -p codewhale-engine verified_candidate --lib -- --nocapture` ran 6 tests, 6 passed on Rocky Linux 8. The runner had no bubblewrap, so Linux-only bodies returned early. `cargo fmt --all -- --check` initially failed; its exported patch was applied in later feature commits.
- CLI SHA256: `d2a18a207bbccf360b45b115ee288268202a59a5c87e60c12e1e41e4f2548d48`.
- Rust test binary SHA256: `58a3c728b11d0b4ace9551188bfa2e4b8018222e20178d0860614bd319ebe6ac`.
- On the authorized 47 VPS (Alibaba Cloud Linux 3, glibc 2.32, bubblewrap
  0.4.0), the same binary ran 6 focused tests: 5 passed, 1 failed. The
  timeout test's generated Python candidate had a quoting `SyntaxError`, so
  it exited in 84 ms with `FAIL` instead of timing out to `UNKNOWN`. The
  prewritten fixture string was corrected at `4ba39ea42797cd25c4c5905bb4a25b1601c369d9`;
  the assertion and production timeout classification were unchanged. See
  `negative-evidence.tar.gz`, `timed-evaluation-first.json`, and
  `timed-evaluation-first.stderr.log`.

## Native CLI probe attempts on the first binary

The `negative-evidence.tar.gz` archive preserves the full temporary fixtures,
CLI streams, local provider ledgers, and Workflow run records for attempts
`e2e-001` through `e2e-005`. Its SHA256 is
`5301cd9912bb83e31d492155469057b38e3fbfd7dcbb9753d6b0e3668a6d94ec`.

| Attempt | Observed outcome | Action taken |
| --- | --- | --- |
| 001 | The inline Workflow text differed from the binary's bundled source and startup rejected it. | Pin the source text to the binary's source commit. |
| 002 | Workers reported success without writing; the file tool refused an unread-file overwrite, and Runtime removed unchanged worktrees. | Script a `read` before `write`. |
| 003 | Both workers wrote files, but delivery verification rejected undeclared changes, leaving no completed candidate for the evaluator. | Use the existing `CHANGES` delivery contract on the opt-in branch. |
| 004 | Both workers' absolute `read` of the hidden oracle failed with `path_escape`; none of 10 provider requests contained the hidden sentinel. The older Workflow's structured response contract still rejected the later unstructured delivery. | Retain the read probe; use the repaired Workflow. |
| 005 | The requested `bash` tool was unavailable in that child tool catalog; absolute `read` remained blocked, and none of 12 provider requests contained the hidden sentinel. The older structured response contract still blocked completion. | Keep this as a tool-catalog observation, not as OS shell isolation evidence. |

The separate `legacy-workflow-native-e2e.py` runner exercised the first
binary without an evaluator. It made two candidate requests and one reviewer
request to the local provider. The Workflow completed with
`scenario: operate-best-of-n`, `review.winner_id: NONE`, and no evaluator
receipts. This is a preliminary native regression control; the final head
will be rerun.

A second writer probe (`e2e-006`, local `tool-search-probe.py`) asked
`tool_search` for `bash`. The catalog returned an unavailable-tool reference;
the following `bash` call was rejected. A direct absolute `read` of the
hidden oracle also failed with `path_escape`; none of 14 provider requests
contained the hidden sentinel. This is tool-catalog and file-tool evidence,
not an executed shell isolation claim.

[Hosted validation at `6754e09`](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43017295415)
passed full CLI build, 6 hosted focused Rust tests, rustfmt, and `cargo check`.
Strict clippy reported one `type_complexity` error in the evaluator's
five-part gate result. Commit `a2887ea0a97d084849c48346943b8a985a430e2f`
replaced the tuple with a named result structure; no lint allowance was added.

## Native acceptance at `4ba39ea`

- [Hosted build artifact](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43019916601):
  full CLI build and 6 focused hosted tests passed. The downloaded ZIP SHA256
  was `a59b18bd40b804a0669615db732b969e9ea8a410536c39cf493a2a69a9e853e8`.
- CLI SHA256: `b6c9c2458b041944eda601ca6292b048f8b5068c8f6cb990ac2ee46df8332a76`.
  Test binary SHA256:
  `9ced1cd4c94c47c89526fbf17343e0b03a060e8226a9366f0ce8e22b5b971e93`.
- On the 47 VPS, `./evaluator-engine-tests verified_candidate --nocapture`
  ran 6 tests, 6 passed in 72.34 s with bubblewrap available. This includes
  public/held-out oracle checks, worktree deletion and replay, artifact
  tampering, identity mismatch, cancellation, timeout, and descendant cleanup.
- Native `workflow-tool` E2E completed with `promotion: proposal_only` and
  `review_only: true`. The fake `PASS/999` candidate failed the host oracle
  over 2 public cases. The malicious candidate passed 2 public cases and 3
  public-plus-held-out replay cases. The receipt reports hidden material
  unexposed to the writer, blocked external/sibling/parent/Git common-dir/HOME
  reads and writes, no credential environment or inherited host descriptor,
  unchanged host fixtures, and no surviving 120-second descendant process.
  The real Workflow result had `FAIL` for candidate 1, `PASS` for candidate 2,
  and `PASS` for candidate 2 replay.
- A separate no-evaluator native CLI E2E ran two candidate requests and the
  existing reviewer request, completed as `operate-best-of-n`, and returned
  no evaluator receipts.
- `positive-4ba39ea.tar.gz` contains the repeatable CLI inputs, native logs,
  Workflow records, sealed evidence, and build receipt. SHA256:
  `438de681c3c0f0871433dcfc8c650a67d08157f360d1dd21ce328fd2a5ae7839`.
- `python verify-native-evidence.py positive-4ba39ea.tar.gz` independently
  recomputed the baseline, two complete candidate tree hashes, artifact
  manifest and blob hashes, frozen manifest, oracle identities, and the
  seven observed case results from saved stdout. It confirmed the Workflow's
  `proposal_only` result and the FAIL/PASS/PASS sequence. This verifier does
  not trust the E2E runner's own `pass` field.

## Final PR head

- PR: https://github.com/codewhale-hq/Codewhale/pull/7294.
- Feature head: `e365276d6a56849fad09e3d30691b219a52bd3ec`; upstream
  base: `3020f4306be1d6a56dbc97cb7b6969e28cdaefa5`.
- The fork-only helper workflow is outside the PR diff. It performs full CLI
  build, focused Rust tests, `cargo fmt --all -- --check`, `cargo check`, and
  focused `cargo clippy -- -D warnings`; build/test logs and binaries are
  retained as a GitHub Actions artifact. Its Rocky Linux 8 container reports
  glibc 2.28; the 47 VPS runs Alibaba Cloud Linux 3, glibc 2.32, and
  bubblewrap 0.4.0.
- [Hosted validation at `e1dca59`](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43023116224)
  and [at `a2887ea`](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43024145240)
  are intermediate history, including the strict clippy/type-complexity and
  rustfmt findings already described above.
- The `a2887ea` fmt job found one `execution_status` line needing rustfmt layout.
  Commit `87a10eed811386148bce2e3e81ba3ef76b72d9d7` applied that exact
  formatting change.
- [Hosted validation at `87a10ee`](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43026289526)
  passed full CLI build and rustfmt before the Windows-only test helper fix.
- The upstream [Windows test job at `87a10ee`](https://github.com/codewhale-hq/Codewhale/actions/runs/43026260652/job/130541884743) failed because Linux-only test helpers produced unused-import/dead-code diagnostics under `-D warnings`. Commit `e365276d6a56849fad09e3d30691b219a52bd3ec` gates only those existing helper declarations with `#[cfg(target_os = "linux")]`. The [Windows test job at `e365276`](https://github.com/codewhale-hq/Codewhale/actions/runs/43028438137/job/130549386165) passed; no evaluator production code changed in that fix.
- [Hosted validation at `e365276`](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43028514457)
  succeeded: `cargo build --locked -p codewhale-cli`,
  `cargo test --locked -p codewhale-engine verified_candidate --lib -- --nocapture`
  (6 passed, 0 failed, 7,178 filtered out), `cargo fmt --all -- --check`,
  `cargo check --locked -p codewhale-engine -p codewhale-workflow-js -p codewhale-sandbox`,
  and `cargo clippy --locked -p codewhale-engine -p codewhale-workflow-js -p codewhale-sandbox --lib -- -D warnings`.
  The hosted runner lacks bubblewrap, so the Linux-only test bodies did not
  execute there. The uploaded binary ZIP SHA256 is
  `e35e59cede3b4fa9e2f4e8b5ad8df178fbd5b00146f47632ae70ec3e44ebbdd7`.
- CLI SHA256: `bc9a5a53b76ae88d51eef21e041f17e1230f12792ee0fa87fab8eec1880f82fd`.
  Rust test binary SHA256:
  `23c90136be0fe9d2b76c26caf96c20cd3ab33ed4959ab8d61ab133be274a987c`.
- The same Rust test binary ran `./evaluator-engine-tests verified_candidate --nocapture`
  on the 47 VPS with bubblewrap available: 6 passed, 0 failed in 71.14 s.
  This includes the real isolation, timeout, cancellation, and descendant
  cleanup paths.
- The exact CLI binary ran the checked-in `scripts/verified-candidate-native-e2e.py`
  through `workflow-tool` with the local scripted provider. Workflow status
  `completed`; self-reported fake PASS failed 2 public cases; the malicious
  candidate passed 2 public cases and 3 public-plus-held-out replay cases.
  Writer hidden sentinel was not exposed. Host, sibling, parent, Git common
  directory, HOME and held-out materials were blocked from candidate read/write;
  inherited descriptor and credential environment probes were blocked;
  120-second descendant was reaped. Final result was `proposal_only`.
- The no-evaluator `legacy-workflow-native-e2e.py` control completed with two
  candidate requests plus the old reviewer, `operate-best-of-n`, `winner_id:
  NONE`, and no evaluator receipts.
- `positive-e365.tar.gz` SHA256:
  `e7dd222bc8a85cbdf72ffecd91b2ec7e8b9623eef6b6990a2af26a4be994f62f`.
  `python verify-native-evidence.py positive-e365.tar.gz` independently
  recomputed the baseline, both sealed trees, artifact manifest/blobs, frozen
  identities and 7 saved outputs, then checked the Workflow result and legacy
  control. It passed without using either E2E runner's self-reported `pass`.
- [Upstream CI at the final head](https://github.com/codewhale-hq/Codewhale/actions/runs/43028438137):
  11 successful applicable checks, 12 skipped by fork/changed-path rules,
  0 failures. The Windows test and Lint jobs both succeeded.
