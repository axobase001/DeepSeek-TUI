#!/usr/bin/env python3
"""Independently verify the host receipts and sealed CAS in a native E2E tar."""

import argparse
import hashlib
import json
import tarfile
from pathlib import PurePosixPath


def sha(data):
    return hashlib.sha256(data).hexdigest()


def compact(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive")
    parser.add_argument("--run", default="e2e-001")
    args = parser.parse_args()
    with tarfile.open(args.archive, "r:gz") as archive:
        names = {member.name: member for member in archive.getmembers()}

        def read(path):
            member = names[path]
            return archive.extractfile(member).read()

        def obj(path):
            return json.loads(read(path))

        prefix = args.run + "/"
        sealed = prefix + "sealed-evidence/"
        manifest_bytes = read(sealed + "manifest.json")
        manifest = json.loads(manifest_bytes)
        baseline = obj(sealed + "baseline.json")
        assert sha(compact(baseline)) == manifest["baseline_id"]
        cases = [obj(prefix + "public.json"), obj(prefix + "hidden.json")]
        requests = obj(prefix + "mock_requests.json")
        assert len(requests) >= 4
        assert {item["candidate"] for item in requests} >= {"cand_001", "cand_002"}
        assert all(not item["hidden_exposed"] for item in requests)
        assert read(prefix + "host-secret") == b"synthetic host secret\n"
        assert read(prefix + "sibling/sibling-secret") == b"synthetic sibling secret\n"
        assert read(prefix + "workspace/.codewhale/parent-secret") == b"synthetic parent secret\n"
        assert read(prefix + "host-home/home-secret") == b"synthetic home secret\n"
        case_hashes = [sha(read(prefix + "public.json")),
                       sha(read(prefix + "hidden.json"))]
        assert case_hashes == manifest["oracle_sha256"]
        build_lines = read("evaluator-build-receipt.txt").decode().splitlines()
        source_sha = build_lines[0]
        binary_sha = next(line.split()[0] for line in build_lines
                          if line.endswith("target/debug/codewhale"))
        assert manifest["native_binary_sha256"] == binary_sha
        for entry in baseline:
            data = read(sealed + "blobs/" + entry["blob_hash"])
            assert len(data) == entry["size_bytes"]
            assert sha(data) == entry["blob_hash"]

        checked_cases = 0
        statuses = {}
        for candidate, suffix in [
            ("candidate_1", "evaluation"),
            ("candidate_2", "evaluation"),
            ("candidate_2", "replay"),
        ]:
            receipt = obj(sealed + candidate + "-" + suffix + ".json")
            artifact_path = sealed + "artifacts/" + candidate + ".json"
            artifact_bytes = read(artifact_path)
            artifact = json.loads(artifact_bytes)
            assert receipt["artifact_manifest_sha256"] == sha(artifact_bytes)
            assert receipt["artifact_id"] == artifact["artifact_id"]
            assert receipt["candidate_tree_hash"] == artifact["candidate_tree_hash"]
            assert artifact["baseline_id"] == manifest["baseline_id"]
            assert receipt["baseline_id"] == manifest["baseline_id"]
            assert receipt["baseline_sha"] == manifest["baseline_sha"]
            assert receipt["spec_sha256"] == manifest["spec_sha256"]
            assert receipt["frozen_manifest_sha256"] == sha(manifest_bytes)
            assert receipt["native_binary_sha256"] == binary_sha
            assert receipt["oracle_sha256"] == case_hashes
            assert receipt["executable_sha256"] == manifest["executable_sha256"]
            assert receipt["sandbox_probe"] == manifest["sandbox_probe"]
            assert receipt["review_only"] is True
            assert receipt["sandbox_probe"]["backend"] == "linux-bwrap"
            assert receipt["sandbox_probe"]["secret_blocked"] is True
            assert receipt["sandbox_probe"]["oracle_paths_blocked"] is True

            tree = {entry["path"]: entry for entry in baseline}
            for change in artifact["entries"]:
                if change["kind"] == "deleted":
                    tree.pop(change["path"])
                else:
                    assert change["kind"] == "file"
                    data = read(sealed + "blobs/" + change["blob_hash"])
                    assert len(data) == change["size_bytes"]
                    assert sha(data) == change["blob_hash"]
                    tree[change["path"]] = {
                        "path": change["path"], "mode": change["mode"],
                        "size_bytes": change["size_bytes"],
                        "blob_hash": change["blob_hash"],
                    }
            tree_entries = [tree[path] for path in sorted(tree)]
            assert sha(compact(tree_entries)) == artifact["candidate_tree_hash"]
            assert artifact["artifact_id"] == artifact["candidate_tree_hash"]

            counted = 0
            all_gates_pass = True
            for gate in receipt["gates"]:
                index = 1 if gate["holdout"] else 0
                assert gate["cases_sha256"] == case_hashes[index]
                assert gate["test_count"] == len(gate["logs"])
                passed = 0
                for log in gate["logs"]:
                    path = PurePosixPath(log["stdout"]).name
                    raw = read(sealed + path).decode().strip()
                    actual = json.loads(raw)
                    expected = cases[index][log["case"] - 1]["expected"]
                    is_pass = (log["exit_code"] == 0
                               and log["stop_reason"] is None
                               and actual == expected)
                    assert log["passed"] is is_pass
                    if candidate == "candidate_1":
                        assert actual == {"status": "PASS", "test_count": 999}
                        assert not is_pass
                    if candidate == "candidate_2":
                        assert all(actual.values())
                    passed += is_pass
                    counted += 1
                assert gate["passed_count"] == passed
                gate_pass = (passed == len(cases[index])
                             and passed >= gate["min_tests"])
                assert (gate["status"] == "PASS") is gate_pass
                all_gates_pass &= gate_pass
            assert counted == receipt["test_count"]
            assert (receipt["status"] == "PASS") is all_gates_pass
            checked_cases += counted
            statuses[candidate + "-" + suffix] = receipt["status"]

        assert statuses == {"candidate_1-evaluation": "FAIL",
                            "candidate_2-evaluation": "PASS",
                            "candidate_2-replay": "PASS"}
        assert checked_cases == 7
        run_records = [json.loads(line)["run"] for line in
                       read(prefix + "workspace/.codewhale/workflow-runs.jsonl")
                       .decode().splitlines() if "run" in json.loads(line)]
        result = run_records[-1]["result"]
        assert run_records[-1]["status"] == "completed"
        assert result["promotion"] == "proposal_only"
        assert result["frozen"]["review_only"] is True
        assert [(item["evaluation"]["status"],
                 (item["replay"] or {}).get("status"))
                for item in result["receipts"]] == [("FAIL", None), ("PASS", "PASS")]
        legacy_verified = False
        if "legacy-001/workspace/.codewhale/workflow-runs.jsonl" in names:
            legacy = [json.loads(line)["run"] for line in
                      read("legacy-001/workspace/.codewhale/workflow-runs.jsonl")
                      .decode().splitlines() if "run" in json.loads(line)][-1]
            legacy_requests = obj("legacy-001/provider_requests.json")
            assert legacy["status"] == "completed"
            assert legacy["result"]["scenario"] == "operate-best-of-n"
            assert legacy["result"]["review"]["winner_id"] == "NONE"
            assert "receipts" not in legacy["result"]
            assert [item["kind"] for item in legacy_requests] == [
                "cand_001", "cand_002", "reviewer"]
            legacy_verified = True
        print(json.dumps({"source_sha": source_sha, "binary_sha256": binary_sha,
                          "checked_cases": checked_cases, "statuses": statuses,
                          "promotion": result["promotion"],
                          "legacy_verified": legacy_verified,
                          "sealed_tree_hashes_verified": 2, "pass": True}))


if __name__ == "__main__":
    main()
