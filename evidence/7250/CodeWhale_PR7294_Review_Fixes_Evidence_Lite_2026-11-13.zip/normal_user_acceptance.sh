#!/usr/bin/env bash
set -euo pipefail

binary=$1
run_dir=$(runuser -u nobody -- mktemp -d /tmp/cw7250-verify.XXXXXX)
tag=$(basename "$run_dir")
pids=()
cleanup() {
    pkill -TERM -u nobody -f "^${tag}-" 2>/dev/null || true
    for pid in "${pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done
}
trap cleanup EXIT

{
    date -u +%FT%TZ
    id nobody
    uname -a
    /usr/bin/bwrap --version
    sha256sum "$binary"
    df -h /
} > "$run_dir/host-preflight.txt"

runuser -u nobody -- /usr/bin/bwrap --unshare-all --die-with-parent \
    --ro-bind /usr /usr --ro-bind /lib /lib --ro-bind /lib64 /lib64 \
    --proc /proc --dev /dev --tmpfs /tmp -- /usr/bin/true \
    > "$run_dir/nonroot-bwrap.log" 2>&1

for i in $(seq 1 40); do
    runuser -u nobody -- bash -c 'exec -a "$1" sleep 900' _ "${tag}-${i}" \
        </dev/null >/dev/null 2>&1 &
    pids+=("$!")
done
sleep 1
task_count=$(ps -eLo uid= | awk '$1 == 65534 { count++ } END { print count + 0 }')
printf 'nobody_owned_tasks=%s\n' "$task_count" | tee "$run_dir/task-preflight.txt"
test "$task_count" -gt 32
set +e
runuser -u nobody -- prlimit --nproc=32:32 -- /usr/bin/bwrap \
    --unshare-all --die-with-parent --ro-bind /usr /usr --ro-bind /lib /lib \
    --ro-bind /lib64 /lib64 --proc /proc --dev /dev --tmpfs /tmp \
    -- /usr/bin/true > "$run_dir/rlimit32-control.log" 2>&1
control_code=$?
set -e
printf 'rlimit32_exit_code=%s\n' "$control_code" >> "$run_dir/task-preflight.txt"
test "$control_code" -ne 0
runuser -u nobody -- prlimit --nproc=4096:4096 -- /usr/bin/bwrap \
    --unshare-all --die-with-parent --ro-bind /usr /usr --ro-bind /lib /lib \
    --ro-bind /lib64 /lib64 --proc /proc --dev /dev --tmpfs /tmp \
    -- /usr/bin/true > "$run_dir/rlimit4096-control.log" 2>&1
runuser -u nobody -- "$binary" verified_candidate --list \
    > "$run_dir/test-list.log" 2>&1
listed=$(grep -c ': test$' "$run_dir/test-list.log" || true)
printf 'listed_tests=%s\n' "$listed" >> "$run_dir/task-preflight.txt"
test "$listed" -ge 9

set +e
runuser -u nobody -- "$binary" verified_candidate --nocapture --test-threads=1 \
    > "$run_dir/test.log" 2>&1
code=$?
set -e
printf 'exit_code=%s\n' "$code" | tee "$run_dir/exit-code.txt"
if test "$code" -eq 0; then
    grep -Eq 'test result: ok\. [0-9]+ passed; 0 failed' "$run_dir/test.log"
fi
printf 'evidence_dir=%s\n' "$run_dir"
exit "$code"
