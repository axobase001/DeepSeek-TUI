# PR #7294 maintainer-review validation ledger

PR: https://github.com/codewhale-hq/Codewhale/pull/7294  
Issue: https://github.com/codewhale-hq/Codewhale/issues/7250  
Feature head under validation: `750eedb774f6c1d43d6689afb7abbd18844968da`  
Authorized Workflow SHA-256: `55d5544578f0f6f5d7e046221a4e11f36fd97b28f94996e640daec271144ca36`

The native Workflow fixtures use a local scripted HTTP provider and synthetic
credentials. No paid model API is involved. Earlier evidence and failures remain
in this directory; this ledger adds the maintainer-review cycle.

## Completed observations

| Platform | Exact command/check | Count and exit | Evidence |
| --- | --- | --- | --- |
| Ubuntu 24.04, upstream PR CI, first review-fix head `3770b94` | `cargo fmt --all -- --check` | exit 1; Rust formatting differences | [CI 43325316900](https://github.com/codewhale-hq/Codewhale/actions/runs/43325316900), Lint job |
| Ubuntu 24.04, upstream PR CI, formatted head `51c9071` | `cargo fmt --all -- --check` | exit 0 | [CI 43326447689](https://github.com/codewhale-hq/Codewhale/actions/runs/43326447689), Lint job |
| Rocky Linux 8, fork helper, implementation head `3770b94` | `cargo build --locked -p codewhale-cli` | exit 0 | [run 43326208005](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43326208005), Linux job |
| Rocky Linux 8, same helper | `cargo test --locked -p codewhale-engine verified_candidate --lib -- --nocapture` | 9 passed, 0 failed, exit 0; bubblewrap absent, Linux-only bodies returned early | same Linux job |
| Rocky Linux 8, same helper | binary collection using `find target/debug/deps` | exit 1: actual test binary was in `target/debug/build/codewhale-engine/.../out/`; helper corrected in fork-only commit `29d834f` | same Linux job |
| Ubuntu 24.04, upstream PR CI, `51c9071` | workspace Clippy with `-D warnings` | exit 101: four `clippy::needless_bool` findings in files outside this PR diff | [CI 43326447689](https://github.com/codewhale-hq/Codewhale/actions/runs/43326447689), Lint job |
| Windows, upstream PR CI, `51c9071` | workspace all-target compile with `-D warnings` | exit 101: unreachable call in `crates/tui/src/tui/ui/terminal.rs:1113`, outside this PR diff | same CI, Windows test job |
| Ubuntu 24.04, upstream current main `5500fee` | workspace Clippy with `-D warnings` | exit 101: same four `needless_bool` locations | [main CI 43327622620](https://github.com/codewhale-hq/Codewhale/actions/runs/43327622620), Lint job |
| Ubuntu 24.04, fork helper, `51c9071` | `cargo fmt --all -- --check` | exit 0 | [run 43329151201](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43329151201), fmt job |
| Ubuntu 24.04, final head `750eedb` | `cargo fmt --all -- --check` | exit 0 | [run 43331027466](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43331027466), fmt job |
| Rocky Linux 8, final head `750eedb` | `cargo build --locked -p codewhale-cli` | exit 0; binary SHA-256 `c2da06b2a23a55443cabbfc90b425656232349e98b97f906c5034a1b2b62f550` | same run, Linux job and `final-750eedb-linux-binaries.zip` |
| Rocky Linux 8, final head `750eedb` | `cargo test --locked -p codewhale-engine verified_candidate --lib -- --nocapture` | exit 0, 9 passed, 0 failed, 7,178 filtered; hosted runner lacked bubblewrap, so Linux-only bodies returned early | same run, Linux job |
| Rocky Linux 8, final head `750eedb` | `cargo check --locked -p codewhale-engine -p codewhale-workflow-js -p codewhale-sandbox` | exit 0 | same run, Linux job |
| Windows 2025, final head `750eedb` | `cargo check --locked -p codewhale-engine -p codewhale-sandbox`; `cargo test --locked -p codewhale-engine verified_candidate --lib -- --nocapture` | both exit 0; 5 passed, 0 failed, 6,863 filtered | same run, Windows job |
| macOS 15, final head `750eedb` | `cargo check --locked -p codewhale-engine -p codewhale-sandbox` | exit 0 | same run, macOS job |
| macOS 15, final head `750eedb` | `cargo clippy --locked -p codewhale-engine -p codewhale-sandbox --lib -- -D warnings` | exit 101: 3 existing `clippy::needless_bool` locations in `auto_review.rs`, `fleet/manager.rs`, and `subagent/coord/ledger.rs`, outside this PR diff | same run, macOS job |
| Rocky Linux 8, final head `750eedb` | `cargo package --list --locked -p codewhale-engine` | exit 0; no repository Workflow script or excluded Rust test source | same run; `final-standard-package-evidence.zip` |
| Rocky Linux 8, final head `750eedb` | `cargo package --locked -p codewhale-engine` | exit 101 during dependency resolution: crates.io does not offer `codewhale-agent ^0.10.3` (latest listed 0.10.2); verification was not bypassed or reported as passing | same run; `final-standard-package-evidence.zip` |
| Rocky Linux 8, final head `750eedb`, fork-only isolated file-set check | Copy exactly the `cargo package --list` engine file set into a fresh source checkout, remove `workflows/operate_best_of_n.workflow.js`, then `cargo check --locked -p codewhale-engine --lib` | exit 0, 6m 33s; local sibling 0.10.3 crates supplied as workspace dependencies | [run 43335601332](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43335601332); `final-package-isolation-evidence.zip` |
| 47 VPS, Alibaba Cloud Linux 3, `nobody` uid 65534, bubblewrap 0.4.0, final binary | 40 owned tasks; `prlimit --nproc=32:32 -- bwrap ...` then `prlimit --nproc=4096:4096 -- bwrap ...` | old 32 control exit 1 with `Creating new namespace failed: Resource temporarily unavailable`; 4096 control exit 0 | `final-750eedb-native-evidence.tar.gz/nonroot-001/` |
| Same non-root VPS, 40 task preflight | `runuser -u nobody -- evaluator-engine-tests verified_candidate --nocapture --test-threads=1` | exit 0, 9 passed, 0 failed, 7,178 filtered, 114.38s; all Linux isolation bodies executed, including timeout/cancellation and delayed-descendant negative control | same archive, `nonroot-001/test.log` |
| Same non-root VPS, native CLI and scripted local provider | `python3.11 native-e2e.py ...`; `python3.11 legacy-e2e.py ...`; modified Workflow identity control | exits 0/0/0: false PASS claim fails 2 public cases; isolated candidate passes 2 public and 3 public-plus-held-out replay cases; `proposal_only`; no-evaluator 3-call legacy path; changed source rejected before evaluator root creation | same archive, `e2e-001/`, `legacy-001/`, `identity-001/` |
| Windows local independent receipt replay | `python verify-native-evidence-7294.py final-750eedb-native-evidence.tar.gz` | exit 0; seven case outputs, two sealed tree hashes, baseline/oracle/binary identities, `proposal_only`, and legacy control recomputed | `verify-native-evidence-7294.py` and same archive |
| Ubuntu 24.04, upstream final-head PR CI | workflow run | 8 success, 12 skipped, 2 failed: workspace Clippy `needless_bool` in four unchanged locations; Windows whole-workspace check `unreachable_code` in unchanged `crates/tui/src/tui/ui/terminal.rs:1113` | [CI 43330938239](https://github.com/codewhale-hq/Codewhale/actions/runs/43330938239) |

Fork-only validation workflow commits `f69eedb`, `4c85886`, `29d834f`,
`b13b7ae`, `41e595e`, and `77db3ac` are outside the PR diff. The final
full-build helper run is [43331027466](https://github.com/axobase001/DeepSeek-TUI/actions/runs/43331027466).

The first native E2E launcher used the VPS default Python 3.6, which lacks
`ThreadingHTTPServer`; it exited before any Workflow execution. Its unchanged
logs are in `python36-first-failure/`. The rerun explicitly used installed
Python 3.11. The historical receipt verifier first failed because it assumed
the two parallel legacy candidate requests arrive in numeric order; the
archived original verifier is preserved, and
`verify-native-evidence-7294.py` accepts either candidate order while still
requiring both candidates followed by the reviewer.

The final native evidence archive SHA-256 is
`3960a725ccb95656dbcbbc71b440940a8c694ece51ea64ccf2f29eab0d18fb09`.
The binary artifact ZIP SHA-256 is
`7ecde1e425890747da607d36bcc2e2bd90dd2a5d10f84454a6bbead06906991f`.
The 47 VPS retained 2.3 GiB free after extracting the two final binaries;
its test-owned 40 tasks were cleaned up after acceptance.

## Remaining gates

- Standard `cargo package --locked -p codewhale-engine` cannot finish while
  its `codewhale-agent 0.10.3` dependency is absent from crates.io. The
  separate file-set check validates the external-script fix against local
  sibling crates, but it is not a crates.io package verification pass.
- Strict Clippy on the PR and macOS helper CI and the upstream whole-workspace
  Windows check remain red in untouched code. The current upstream `main`
  [CI 43327622620](https://github.com/codewhale-hq/Codewhale/actions/runs/43327622620)
  reproduces the four Linux Clippy findings.
