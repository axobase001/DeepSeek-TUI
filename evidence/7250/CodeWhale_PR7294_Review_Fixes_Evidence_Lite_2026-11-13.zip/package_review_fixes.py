#!/usr/bin/env python3
"""Bundle the final PR #7294 review evidence with checked file identities."""

import hashlib
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
FULL = ROOT.parent / "CodeWhale_PR7294_Review_Fixes_Evidence_2026-11-13.zip"
LITE = ROOT.parent / "CodeWhale_PR7294_Review_Fixes_Evidence_Lite_2026-11-13.zip"
FILES = [
    "PR7294_review_fixes_README.md",
    "PR7294_review_fixes_validation_2026-11-13.md",
    "final-750eedb-linux-binaries.zip",
    "final-750eedb-native-evidence.tar.gz",
    "final-standard-package-evidence.zip",
    "final-package-isolation-evidence.zip",
    "normal_user_acceptance.sh",
    "native_workflow_acceptance.sh",
    "verified-candidate-native-e2e.py",
    "legacy-workflow-native-e2e.py",
    "workflow_identity_control.py",
    "verify-native-evidence-7294.py",
    "package_review_fixes.py",
    "README.md",
    "validation-ledger.md",
    "positive-e365.tar.gz",
    "positive-4ba39ea.tar.gz",
    "negative-evidence.tar.gz",
    "timed-evaluation-first.json",
    "timed-evaluation-first.stderr.log",
    "tool-search-probe.py",
    "verify-native-evidence.py",
    "package_evidence.py",
    "old-rustfmt-patch.zip",
    "preliminary-package-evidence.zip",
    "remote-head.commit",
]


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def info(name):
    item = zipfile.ZipInfo(name, date_time=(2026, 11, 13, 0, 0, 0))
    item.compress_type = (
        zipfile.ZIP_STORED if name.endswith((".zip", ".gz")) else zipfile.ZIP_DEFLATED
    )
    item.create_system = 3
    item.external_attr = 0o644 << 16
    return item


def make_bundle(output, files):
    checksums = "".join(f"{digest(ROOT / name)}  {name}\n" for name in sorted(files))
    with zipfile.ZipFile(output, "w", allowZip64=True) as archive:
        for name in sorted(files):
            with (ROOT / name).open("rb") as source, archive.open(info(name), "w") as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)
        archive.writestr(info("SHA256SUMS.txt"), checksums)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for line in checksums.splitlines():
            expected, name = line.split("  ", 1)
            result = hashlib.sha256()
            with archive.open(name) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    result.update(block)
            assert result.hexdigest() == expected, name
    print(f"{output.name} bytes={output.stat().st_size} sha256={digest(output)} files={len(files)}")


def main():
    make_bundle(LITE, [name for name in FILES if name != "final-750eedb-linux-binaries.zip"])
    make_bundle(FULL, FILES)


if __name__ == "__main__":
    main()
