#!/usr/bin/env bash
set -euo pipefail

binary=$1
source_sha=$2
scripts=/tmp/cw7250-scripts
base=$(runuser -u nobody -- mktemp -d /tmp/cw7250-native.XXXXXX)
runuser -u nobody -- mkdir "$base/home" "$base/tmp"
printf '%s\n' "$base" > /tmp/cw7250-latest-native-evidence-path
{
    printf 'source_sha=%s\n' "$source_sha"
    sha256sum "$binary" "$scripts/operate.workflow.js"
    date -u +%FT%TZ
    id nobody
    df -h /
} > "$base/preflight.txt"

set +e
runuser -u nobody -- env HOME="$base/home" TMPDIR="$base/tmp" \
    python3.11 "$scripts/native-e2e.py" --codewhale "$binary" \
    --workflow-source "$scripts/operate.workflow.js" \
    --output "$base/e2e-001" --source-sha "$source_sha" \
    > "$base/e2e-001.log" 2>&1
e2e_status=$?

runuser -u nobody -- env HOME="$base/home" TMPDIR="$base/tmp" \
    python3.11 "$scripts/legacy-e2e.py" --codewhale "$binary" \
    --workflow-source "$scripts/operate.workflow.js" \
    --output "$base/legacy-001" --source-sha "$source_sha" \
    > "$base/legacy-001.log" 2>&1
legacy_status=$?

if test -f "$base/e2e-001/evaluator.json"; then
    runuser -u nobody -- env HOME="$base/home" TMPDIR="$base/tmp" \
        python3.11 /tmp/cw7250-workflow-identity-control.py \
        --codewhale "$binary" --workflow-source "$scripts/operate.workflow.js" \
        --fixture-dir "$base/e2e-001" --output "$base/identity-001" \
        > "$base/identity-001.log" 2>&1
    identity_status=$?
else
    identity_status=99
fi
set -e

printf 'e2e_exit=%s\nlegacy_exit=%s\nidentity_exit=%s\n' \
    "$e2e_status" "$legacy_status" "$identity_status" | tee "$base/status.txt"
printf 'evidence_dir=%s\n' "$base"
test "$e2e_status" -eq 0
test "$legacy_status" -eq 0
test "$identity_status" -eq 0
