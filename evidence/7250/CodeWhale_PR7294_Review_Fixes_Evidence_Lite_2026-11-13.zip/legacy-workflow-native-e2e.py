#!/usr/bin/env python3
"""Check the existing no-evaluator Workflow path through the real CLI."""

import argparse
import hashlib
import json
import os
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


def stream(value):
    chunks = [
        {"id": "legacy-local", "choices": [{"index": 0, "delta": {"content": value},
                                          "finish_reason": None}]},
        {"id": "legacy-local", "choices": [{"index": 0, "delta": {},
                                          "finish_reason": "stop"}]},
        {"id": "legacy-local", "choices": [],
         "usage": {"prompt_tokens": 8, "completion_tokens": 8, "total_tokens": 16}},
    ]
    return ("".join("data: " + json.dumps(chunk) + "\n\n" for chunk in chunks)
            + "data: [DONE]\n\n").encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--codewhale", type=Path, required=True)
    parser.add_argument("--workflow-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-sha", required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "workspace"
    workspace.mkdir()
    (workspace / "README.md").write_text("Synthetic legacy Workflow task.\n")
    for git_args in [
        ["init", "-q"], ["add", "."],
        ["-c", "user.name=Native E2E", "-c", "user.email=native@example.invalid",
         "commit", "-qm", "baseline"],
    ]:
        subprocess.run(["git", "-C", str(workspace), *git_args], check=True)
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def do_GET(self):
            body = b'{"object":"list","data":[]}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            messages = json.dumps(request.get("messages", []))
            if "read-only tournament judge" in messages:
                kind = "reviewer"
                value = {"winner_id": "NONE", "ranking": [],
                         "verification_required": True,
                         "reasons": ["No verified candidate in this synthetic run."]}
            else:
                kind = next((item for item in ("cand_001", "cand_002")
                             if item in messages), "unexpected")
                value = {"candidate_id": kind, "hypothesis": "no change fixture",
                         "modified_paths": [], "commands_run": [],
                         "self_verdict": "fail", "known_risks": [],
                         "artifact_refs": []}
            requests.append({"kind": kind, "model": request.get("model")})
            body = stream(json.dumps(value))
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    config = output / "config.toml"
    config.write_text('provider = "deepseek"\n[providers.deepseek]\n'
                      f'model = "deepseek-flash"\nbase_url = "http://127.0.0.1:{server.server_port}/v1"\n')
    payload = {"action": "run", "script": args.workflow_source.read_text(),
               "args": {"strategy": "best_of_n", "brief": "Synthetic legacy task",
                        "n": 2, "model": "deepseek-flash"}}
    env = os.environ.copy()
    env.update({"DEEPSEEK_API_KEY": "synthetic-local-only",
                "CODEWHALE_HOME": str(output / "home"),
                "CODEWHALE_TELEMETRY": "0", "CODEWHALE_NO_UPDATE_CHECK": "1",
                "HTTP_PROXY": "http://127.0.0.1:9",
                "HTTPS_PROXY": "http://127.0.0.1:9",
                "NO_PROXY": "127.0.0.1,localhost"})
    command = [str(args.codewhale.resolve()), "--config", str(config),
               "--workspace", str(workspace), "--provider", "deepseek",
               "--model", "deepseek-flash", "--sandbox-mode", "workspace-write",
               "workflow-tool", "--approval-source", "explicit-workflow-command",
               "--input-json", json.dumps(payload, separators=(",", ":"))]
    try:
        completed = subprocess.run(command, cwd=workspace, env=env,
                                   capture_output=True, text=True, timeout=180)
    finally:
        server.shutdown()
        thread.join(timeout=5)
    (output / "stdout.log").write_text(completed.stdout)
    (output / "stderr.log").write_text(completed.stderr)
    (output / "provider_requests.json").write_text(json.dumps(requests, indent=2) + "\n")
    records = workspace / ".codewhale/workflow-runs.jsonl"
    runs = [json.loads(line)["run"] for line in records.read_text().splitlines()
            if "run" in json.loads(line)] if records.exists() else []
    run = runs[-1] if runs else {}
    result = run.get("result") or {}
    receipt = {"source_sha": args.source_sha,
               "binary_sha256": hashlib.sha256(args.codewhale.read_bytes()).hexdigest(),
               "exit_code": completed.returncode,
               "workflow_status": run.get("status"),
               "scenario": result.get("scenario"),
               "has_evaluator_receipts": "receipts" in result,
               "review_winner": (result.get("review") or {}).get("winner_id"),
               "provider_requests": requests}
    receipt["pass"] = (receipt["exit_code"] == 0
                       and receipt["workflow_status"] == "completed"
                       and receipt["scenario"] == "operate-best-of-n"
                       and not receipt["has_evaluator_receipts"]
                       and receipt["review_winner"] == "NONE"
                       and len(requests) == 3)
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return 0 if receipt["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
