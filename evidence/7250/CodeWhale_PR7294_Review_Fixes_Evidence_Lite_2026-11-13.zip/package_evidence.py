#!/usr/bin/env python3
"""Produce deterministic, self-checking full and public evidence bundles."""

import hashlib
import shutil
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
COMMON = [
    "README.md",
    "validation-ledger.md",
    "verify-native-evidence.py",
    "package_evidence.py",
    "positive-e365.tar.gz",
    "positive-4ba39ea.tar.gz",
    "negative-evidence.tar.gz",
    "timed-evaluation-first.json",
    "timed-evaluation-first.stderr.log",
    "tool-search-probe.py",
    "legacy-workflow-native-e2e.py",
]
BUILD = "final-e365-binaries.zip"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def zip_info(name, stored=False):
    info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
    info.compress_type = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o644 << 16
    return info


def make_bundle(name, paths):
    output = HERE.parent / name
    checksums = "".join(
        f"{sha256(HERE / path)}  {path}\n" for path in sorted(paths)
    ).encode()
    with zipfile.ZipFile(output, "w", allowZip64=True) as archive:
        for path in sorted(paths):
            with (HERE / path).open("rb") as source, archive.open(
                zip_info(path, stored=path.endswith((".zip", ".gz"))), "w"
            ) as target:
                shutil.copyfileobj(source, target, length=1024 * 1024)
        archive.writestr(zip_info("SHA256SUMS.txt"), checksums)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for line in checksums.decode().splitlines():
            expected, path = line.split("  ", 1)
            digest = hashlib.sha256()
            with archive.open(path) as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            assert digest.hexdigest() == expected, path
    print(f"{output.name} {output.stat().st_size} bytes sha256:{sha256(output)}")


if __name__ == "__main__":
    make_bundle("Codewhale_7250_Evaluator_Evidence_Lite_2026-11-11.zip", COMMON)
    make_bundle("Codewhale_7250_Evaluator_Evidence_Full_2026-11-11.zip", COMMON + [BUILD])
